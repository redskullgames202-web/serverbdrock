package com.example.capri

import android.content.Context
import android.graphics.*
import android.view.View

/** Avatar neon desenhado em código (troque por sua própria arte se quiser). */
class CapriView(c: Context) : View(c) {
    var state = 0 // 0 parada, 1 ouvindo, 2 pensando, 3 falando
        set(v) { field = v; invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    init { setLayerType(LAYER_TYPE_SOFTWARE, null) }

    override fun onDraw(c: Canvas) {
        val col = Color.parseColor(when (state) { 1 -> "#FF2E97"; 2 -> "#FCEE09"; else -> "#00F0FF" })
        val cx = width / 2f; val cy = height / 2f; val r = width * 0.34f
        p.style = Paint.Style.FILL; p.color = Color.parseColor("#0B0B14")
        p.setShadowLayer(width * 0.1f, 0f, 0f, col)
        c.drawCircle(cx, cy, r, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = width * 0.04f; p.color = col
        c.drawCircle(cx, cy, r, p)
        p.clearShadowLayer(); p.style = Paint.Style.FILL
        val ey = cy - r * 0.15f
        c.drawCircle(cx - r * 0.4f, ey, r * 0.13f, p)
        c.drawCircle(cx + r * 0.4f, ey, r * 0.13f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = width * 0.03f; p.strokeCap = Paint.Cap.ROUND
        val my = cy + r * 0.4f
        if (state == 3) c.drawOval(cx - r * 0.2f, my - r * 0.1f, cx + r * 0.2f, my + r * 0.15f, p)
        else c.drawLine(cx - r * 0.25f, my, cx + r * 0.25f, my, p)
    }
}
