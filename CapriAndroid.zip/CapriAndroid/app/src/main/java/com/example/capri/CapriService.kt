package com.example.capri

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.*
import android.speech.*
import android.speech.tts.TextToSpeech
import android.view.*
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.math.abs

class CapriService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var box: LinearLayout
    private lateinit var face: CapriView
    private lateinit var caption: TextView
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var torch = false
    private val main = Handler(Looper.getMainLooper())
    private val history = JSONArray()

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val ch = "capri"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "Capri", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, ch).setContentTitle("Capri ativa")
            .setContentText("Toque nela para falar").setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        if (Build.VERSION.SDK_INT >= 30) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
        tts = TextToSpeech(this) { if (it == TextToSpeech.SUCCESS) tts?.language = Locale.getDefault() }
        buildBubble()
    }

    private fun buildBubble() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val d = resources.displayMetrics.density
        face = CapriView(this)
        caption = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 13f; setPadding(16, 8, 16, 8)
            setBackgroundColor(0xCC0B0B14.toInt()); maxWidth = (240 * d).toInt(); visibility = View.GONE
        }
        box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            addView(face, LinearLayout.LayoutParams((110 * d).toInt(), (110 * d).toInt()))
            addView(caption)
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 40; y = 300 }
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        box.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                    if (abs(dx) > 15 || abs(dy) > 15) moved = true
                    lp.x = sx + dx; lp.y = sy + dy; wm.updateViewLayout(box, lp)
                }
                MotionEvent.ACTION_UP -> if (!moved) listen()
            }
            true
        }
        wm.addView(box, lp)
    }

    private fun say(text: String, speak: Boolean = true) {
        caption.text = text; caption.visibility = View.VISIBLE
        main.removeCallbacksAndMessages(null)
        main.postDelayed({ caption.visibility = View.GONE }, 8000)
        face.state = if (speak) 3 else 0
        if (speak) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "capri")
        main.postDelayed({ face.state = 0 }, if (speak) 3000L else 0L)
    }

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { say("Reconhecimento de voz indisponível.", false); return }
        tts?.stop(); recognizer?.destroy()
        face.state = 1; caption.visibility = View.GONE
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle?) {
                    val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (t.isNullOrBlank()) say("Não entendi.", false) else handle(t)
                }
                override fun onError(e: Int) { say("Não ouvi nada. Toque e fale de novo.", false) }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            })
        }
    }

    private fun handle(text: String) {
        val t = text.lowercase(Locale.getDefault())
        Regex("^(abr[aeir]+|open)\\s+(o |a )?(.+)$").find(t)?.let { m ->
            if (openApp(m.groupValues[3].trim())) say("Abrindo ${m.groupValues[3]}.") else say("Não achei esse app.")
            return
        }
        if (t.contains("lanterna") || t.contains("flashlight")) { toggleTorch(); return }
        ask(text)
    }

    private fun openApp(name: String): Boolean {
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(name) } ?: return false
        val i = pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return false
        startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return true
    }

    private fun toggleTorch() {
        try {
            val cm = getSystemService(CameraManager::class.java)
            val id = cm.cameraIdList.first { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            torch = !torch; cm.setTorchMode(id, torch)
            say(if (torch) "Lanterna ligada." else "Lanterna desligada.")
        } catch (e: Exception) { say("Não consegui usar a lanterna.") }
    }

    private fun ask(text: String) {
        val key = getSharedPreferences("capri", Context.MODE_PRIVATE).getString("key", "") ?: ""
        if (key.isBlank()) { say("Coloque sua chave de API no app primeiro."); return }
        face.state = 2
        history.put(JSONObject().put("role", "user").put("content", text))
        while (history.length() > 10) history.remove(0)
        Thread {
            val reply = try {
                val body = JSONObject()
                    .put("model", "claude-haiku-5-5").put("max_tokens", 300)
                    .put("system", "Você é Capri, uma IA companheira de estilo cyberpunk que vive na tela do celular do usuário. " +
                        "Responda no idioma dele, em 1 ou 2 frases curtas, em tom casual, sem markdown, pois sua resposta será falada em voz alta.")
                    .put("messages", history)
                val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
                c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 30000
                c.setRequestProperty("x-api-key", key)
                c.setRequestProperty("anthropic-version", "2023-06-01")
                c.setRequestProperty("content-type", "application/json")
                c.outputStream.use { it.write(body.toString().toByteArray()) }
                if (c.responseCode != 200) "Erro ${c.responseCode}. Confira sua chave de API."
                else JSONObject(c.inputStream.bufferedReader().readText())
                    .getJSONArray("content").getJSONObject(0).getString("text")
            } catch (e: Exception) { "Sem conexão com a IA." }
            main.post {
                history.put(JSONObject().put("role", "assistant").put("content", reply))
                say(reply)
            }
        }.start()
    }

    override fun onDestroy() {
        if (::box.isInitialized) wm.removeView(box)
        recognizer?.destroy(); tts?.shutdown(); super.onDestroy()
    }
}
