package com.example.capri

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private lateinit var keyBox: EditText

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val d = resources.displayMetrics.density
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding((24 * d).toInt(), (48 * d).toInt(), (24 * d).toInt(), 24 * d.toInt())
            setBackgroundColor(0xFF0B0B14.toInt())
        }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }.also { col.addView(it) }
        col.addView(TextView(this).apply { text = "CAPRI"; textSize = 32f; setTextColor(0xFF00F0FF.toInt()); gravity = Gravity.CENTER })
        col.addView(TextView(this).apply {
            text = "Cole sua chave de API da Anthropic (fica só neste aparelho):"; setTextColor(0xFFCCCCCC.toInt())
        })
        keyBox = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setTextColor(0xFFFFFFFF.toInt())
            setText(getSharedPreferences("capri", MODE_PRIVATE).getString("key", ""))
        }
        col.addView(keyBox)
        btn("1. Salvar chave") {
            getSharedPreferences("capri", MODE_PRIVATE).edit().putString("key", keyBox.text.toString().trim()).apply()
            Toast.makeText(this, "Salva!", Toast.LENGTH_SHORT).show()
        }
        btn("2. Permitir exibir sobre outros apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("3. Iniciar Capri") { start() }
        btn("Parar Capri") { stopService(Intent(this, CapriService::class.java)) }
        setContentView(col)
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) { Toast.makeText(this, "Faça o passo 2 primeiro", Toast.LENGTH_LONG).show(); return }
        val need = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) need += Manifest.permission.POST_NOTIFICATIONS
        val missing = need.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 1) else launch()
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) launch()
        else Toast.makeText(this, "Preciso do microfone para ouvir você", Toast.LENGTH_LONG).show()
    }

    private fun launch() { startForegroundService(Intent(this, CapriService::class.java)); moveTaskToBack(true) }
}
